package utils;

public class ReportManager {

}
